create trigger payment_date
  before INSERT
  on payment
  for each row
  SET NEW.payment_date = NOW();

